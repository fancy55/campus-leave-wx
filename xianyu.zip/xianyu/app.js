//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null, //得到的本人数据
    phone: null,
    idCard: null,
    realInfo: null,  //真实数据
    resetInfo: null,  //修改数据
    index: null,     //点击事件获得的下标
    indexId: null,    //点击事件获得的信息
    whichPage: null,  //粉丝和关注是哪一页,
    receive: null,  //得到的
    focus: null,    //判断是点开关注还是粉丝
    fans: null,     //判断是点开关注还是粉丝
    page: null,     //显示粉丝还是关注
    mySet: true,     //看是否在发布页面，是则false；否则true
    isBuy: false,     //是否在交易页面
    whichBuy:true,   //在交易的哪个页面
    idCard:"430781200012120524",
    nickName:"fancy",
    photo:"http://www.qlybit.xyz:8089/photo/152-8127-7b2b3be7-5b9f-4cc4-b070-b6f141df3a50.png"
  }
})