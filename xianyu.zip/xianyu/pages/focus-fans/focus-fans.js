// pages/focus-fans/focus-fans.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    focus: app.globalData.focus,
    fans: app.globalData.fans,
    page: true,
    arrFocus: [],
    arrFans: [],
    focusInfo: [],
    fansInfo: []
  },
  // 点击关注界面
  tickFocus: function () {
    var that = this;
    this.setData({
      focus: "focus",
      fans: "fansdis",
      page: true
    })

  },
  // 点击粉丝界面
  tickFans: function () {
    var that = this;
    this.setData({
      focus: "focusdis",
      fans: "fans",
      page: false
    })

  },
  // 去哪个个人界面
  getOther: function (e) {
    var index = e.currentTarget.dataset.index;
    console.log("得到index", index)
    app.globalData.index = index;
    if (this.data.focus == "focus") {
      console.log("查看index", index)
      app.globalData.indexId = this.data.arrFocus[index];
      console.log("得到的点击关注用户信息", app.globalData.indexId);
      wx.navigateTo({
        url: '../otherPage/otherPage'
      })
    } else {
      app.globalData.indexId = this.data.arrFans[index],
        console.log("得到的点击粉丝用户信息", app.globalData.indexId);
      wx.navigateTo({
        url: '../otherPage/otherPage'
      })
    }
  },
  //取消关注，
  cancel: function (e) {
    var index = e.currentTarget.dataset.index;
    var msg = JSON.stringify({
      "idCard": app.globalData.userInfo.idCard,
      "publishIdCard": this.data.arrFocus[index].idCard
    })
    console.log("取消关注的人", index)
    wx.request({
      url: 'http://47.104.191.228:8088/cancel/focus',
      method: "post",
      data: {
        "type": "cancel",
        "msg": msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res.data);
        this.onLoad();
      },
    })
  },
  //除移粉丝
  remove: function (e) {
    var index = e.currentTarget.dataset.index;
    console.log(index)
    var realIndex = this.data.arrFans.length - index - 1;
    var that = this;
    var msg = JSON.stringify({
      "publishIdCard": app.globalData.userInfo.idCard,
      "idCard": this.data.arrFans[index].idCard  //发现信息和取消的人是倒序排列的
    })
    wx.request({
      url: 'http://47.104.191.228:8088/remove/focus',
      method: "post",
      data: {
        "type": "remove",
        "msg": msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res.data);
        this.onLoad();
      },
    })
  },
  // 获取关注数据
  getFocus: function () {
    var that = this;
    wx.request({
      url: "http://47.104.191.228:8088/get/focus",
      method: "get",
      data: {
        "msg": {
          "idCard": app.globalData.userInfo.idCard
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        that.setData({
          arrFocus: res.data.msg
        });
      }
    })
  },
  //获取我的粉丝数据
  getFans: function () {
    var that = this
    wx.request({
      url: "http://47.104.191.228:8088/get/fans",
      method: "get",
      data: {
        "msg": {
          "publishIdCard": app.globalData.userInfo.idCard
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        that.setData({
          arrFans: res.data.msg
        });
        // console.log("得到我的粉丝数据",that.data.arrFans);

      }
    })
  },
  //根据我关注或我粉丝，获取其信息
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getFocus();
    this.getFans();
    this.setData({
      focus: app.globalData.focus,
      fans: app.globalData.fans,
      page: app.globalData.page,
    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.onLoad();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})