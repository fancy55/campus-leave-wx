// pages/resetInfo/changePhone/changePhone.js
const app=getApp();
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    phone:null,
    form:null
  },
  getnumber:function(e){
    console.log(e.detail.value);
    var number = e.detail.value;
    if(number.length!=11){
      wx.showToast({
        title: '请输入正确手机号',
        icon:"none"
      })
    }else{
      this.setData({
        phone: e.detail.value
      })
    }
  },
  formSubmit:function(e){
  console.log(e.detail.value);
  this.setData({
    form: e.detail.value
  })
    var judge = wx.getStorageSync("code")
    console.log(this.data.form.code == judge)
    if (this.data.form.code == judge){
      var msg = JSON.stringify({
        "phone":this.data.phone,
        "idCard":app.globalData.userInfo.idCard
      });
      var that = this;
      // 修改内容
      wx.request({
        url: 'http://47.104.191.228:8088/user/alter',
        method: "post",
        data: {
          msg: msg
        },
        dataType: "json",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: (res) => {
          console.log(res.data)
          wx.showToast({
            title: res.data,
            icon: 'success',
            duration: 2000
          }),
            wx.navigateTo({
              url: '../resetInfo'
            })
          app.globalData.userInfo.phone=this.data.phone;
        },
        fail(res) {
          console.log(res)
        }
      })
    }
  },
  getCode:function(){
   console.log("获取验证码",this.data.phone);
    var phone = this.data.phone
    var that = this
    // console.log(phone)
    if (phone.length == 11) {
      wx.request({
        url: 'http://47.104.191.228:8088/send/' + phone,
        method: "get",
        dataType: "json",
        header: {
          "Content-Type": "application/json;charset=UTF-8"
        },
        success: (res) => {
          console.log(res)
          var list = res.data.data.split(',')
          var code = list[0].slice(5)
          console.log(code)
          wx.setStorageSync("code", code)
        }
      })
      wx.showToast({
        title: '请稍候',
        icon: 'loading',
        duration: 1000
      })
    } else {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none',
        duration: 1000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})