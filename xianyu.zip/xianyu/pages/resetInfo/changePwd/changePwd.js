// pages/resetInfo/changePwd/changePwd.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
     right:null,
     newpassword:null,
     all:null
  },
  getbefore: function (e) {
    console.log(e.detail.value);
    var number = e.detail.value;
    if (number!= app.globalData.userInfo.password) {
      wx.showToast({
        title: '请输入正确原密码',
        icon: "none"
      })
    } else {
      this.setData({
        right: true
      })
      console.log(this.data.right);
    }
  },
  getnew:function(e){
    if(this.data.right=true){
     var newN =e.detail.value;
      if (newN.length >= 6 && newN.length<=10){
        this.setData({
          newpassword:newN
        })
        console.log(this.data.newpassword);
      }else{
        wx.showToast({
          title: '请输入正确格式的密码',
          icon:'none'
        })
      }
    }
  },
  getre:function(e){
    if (this.data.newpassword != null && e.detail.value == this.data.newpassword){
       this.setData({
        all:true
       })
       console.log(this.data.all)
    }else{
      wx.showToast({
        title: '前后输入不一致',
        icon: 'none'
      })
    }
  },
  formSubmit:function(){
    if(this.data.all){
      var msg = JSON.stringify({
        "password": this.data.newpassword,
        "idCard": app.globalData.userInfo.idCard
      });
      var that = this;
      // 修改内容
      wx.request({
        url: 'http://47.104.191.228:8088/user/alter',
        method: "post",
        data: {
          msg: msg
        },
        dataType: "json",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: (res) => {
          console.log(res.data)
          wx.showToast({
            title: res.data,
            icon: 'success',
            duration: 2000
          }),
            wx.navigateTo({
              url: '../resetInfo'
            })
          app.globalData.userInfo.password = this.data.newpassword;
        },
        fail(res) {
          console.log(res)
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})