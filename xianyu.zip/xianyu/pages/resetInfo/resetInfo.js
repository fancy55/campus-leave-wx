// pages/resetInfo/resetInfo.js
const app = getApp();
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tempFilePaths: '',
    photo:'',
    nickName: '',
    sex: '',
    name: '',
    idCard: '',
    phone: '',
    address: '',
    college: '',
    grade: '',
    major: ''

  },
  changePwd:function() {
    wx.navigateTo({
      url: 'changePwd/changePwd',
    })
  },
  changePhone:function(){
    wx.navigateTo({
      url: 'changePhone/changePhone',
    })
  },
  getPhoto:function(){
    var that=this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        console.log(res)
        that.setData({
          tempFilePaths:res.tempFilePaths,
          photo: res.tempFilePaths
        })
        
      }
    })
     
  },
  
  //替代指定位置字符串；
  replaceIt: function (text, start, stop, replacetext){
      var mystr = text.substring(0, start) + replacetext + text.substring(stop);
      return mystr;
  },
  setInfo: function () {
    this.setData({
      nickName: app.globalData.userInfo.nickName,
      photo: app.globalData.userInfo.photo,
      address: app.globalData.userInfo.address,
      sex: app.globalData.userInfo.sex,
      age: app.globalData.userInfo.age,
      college: app.globalData.userInfo.college,
      grade: app.globalData.userInfo.grade,
      major: app.globalData.userInfo.major,
      name: app.globalData.userInfo.name,
      phone: app.globalData.userInfo.phone,
      idCard: app.globalData.userInfo.idCard
    })
  },

  formSubmit: function (e) {
    // console.log(app.globalData.userInfo)
    app.globalData.resetInfo = e.detail.value;
    var msg = JSON.stringify({
      "nickName": app.globalData.resetInfo.nickName,
      "sex": app.globalData.resetInfo.sex,
      "age": app.globalData.resetInfo.age,
      "address": app.globalData.resetInfo.address,
      "college": app.globalData.resetInfo.college,
      "grade": app.globalData.resetInfo.grade,
      "major": app.globalData.resetInfo.major,
      "idCard": app.globalData.userInfo.idCard,
      "date": util.formatTime(new Date())
    });
    var that=this;
    // 修改内容
    wx.request({
      url: 'http://47.104.191.228:8088/user/alter',
      method: "post",
      data: {
        msg: msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res.data)
        wx.showToast({
          title: res.data,
          icon: 'success',
          duration: 2000
        }),
        wx.switchTab({
          url: '../My/My'
        })
      },
      fail(res){
        console.log(res)
      }
    })
    // 修改头像
    if (this.data.tempFilePaths[0]){
    var thisMsg=JSON.stringify({
      "idCard": app.globalData.userInfo.idCard
    })
    wx.uploadFile({
      url: 'http://47.104.191.228:8088/user/alter/photo',
      filePath: this.data.tempFilePaths[0],
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data"
      },
      formData: {
        msg:thisMsg
      },
      success(res) {
        console.log(res);
        wx.showToast({
          title: res.data,
          icon: 'success',
          duration: 2000
        }),
        wx.switchTab({
          url: '../My/My'
        })
      },
      fail(res) {
        console.log(res)
      }
    })
    app.globalData.userInfo.photo = this.data.tempFilePaths[0];
    }

  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setInfo();
    console.log(this.replaceIt(app.globalData.userInfo.phone,3,7,"****"))

    this.setData({
      phone: this.replaceIt(app.globalData.userInfo.phone, 3, 7, "****"),
        idCard: this.replaceIt(app.globalData.userInfo.idCard, 3, 14, "*******")
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {


  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})