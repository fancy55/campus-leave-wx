// pages/Login2/Login2.js
const app = getApp();
var util = require('../../utils/util.js');


Page({
  /**
   * 页面的初始数据
   */
  data: {
    form: [],
    name: "",
    number: "",
    verifyNumber: "",  //输入的验证码
    idcard: "",
    photo:null,
    tempFilePaths:[],
    judgeNumber:123456,  //正确的验证码
    newpassword:null,
    all:null
  },
  //得到密码
  getnew: function (e) {
      var newN = e.detail.value;
      if (newN.length >= 6 && newN.length <= 10) {
        this.setData({
          newpassword: newN
        })
        console.log(this.data.newpassword);
      } else {
        wx.showToast({
          title: '请输入正确格式的密码',
          icon: 'none'
        })
      }
  },
  getre: function (e) {
    if (this.data.newpassword != null && e.detail.value == this.data.newpassword) {
      this.setData({
        all: true
      })
      console.log(this.data.all)
    } else {
      wx.showToast({
        title: '前后输入不一致',
        icon: 'none'
      })
    }
  },
  //得到电话号码以便发验证码
  inputNumber: function (e) {
    this.setData({
      number: e.detail.value
    })
  },
  //去登陆
  toLogin:function(){
    wx.navigateTo({
      url: '../inThis/inThis',
    })
  },
  // 得到手机号
  getNumber: function () {
    var phone = this.data.number
    var that = this
    // console.log(phone)
    if (phone.length == 11) {
      wx.request({
        url: 'http://47.104.191.228:8088/send/'+phone,
        method: "get",
        dataType:"json",
        header: {
          "Content-Type": "application/json;charset=UTF-8"
        },
        success: (res) => {
          console.log(res)
          var list=res.data.data.split(',')
          var code=list[0].slice(5)
          console.log(code)
          wx.setStorageSync("code", code)
        }
      })
      wx.showToast({
        title: '请稍候',
        icon: 'loading',
        duration: 1000
      })
    } else {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none',
        duration: 1000
      })
    }
  },
  //得到图片
  getPhoto: function () {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        console.log(res)
        that.setData({
          tempFilePaths: res.tempFilePaths,
          photo: res.tempFilePaths
        })
      }
    })

  },
  // 注册存储函数
  register: function () {
    var that = this;
    var photo=this.data.tempFilePaths[0];
    var msg = JSON.stringify({
      name: this.data.form.name,
      phone: this.data.form.phone,
      idCard: this.data.form.idCard,
      address:"请输入地址",
      grade:"年级",
      age:"0",
      sex:"无",
      nickName:"昵称",
      college:"学院",
      major:"专业",
      password:this.data.newpassword,
      date: util.formatTime(new Date())
    })
    // console.log("输入转字符串",msg)
      app.globalData.realInfo = this.data.form
      //把注册文件传进去
      wx.uploadFile({
        url: 'http://47.104.191.228:8088/user/insert',
        filePath:photo,
        name: 'file',
        header: {
          "Content-Type": "multipart/form-data"
        },
        formData: {
          'msg':msg
        },
        success(res) {
          console.log(res);
          wx.showToast({
            title: res.data,  //返回注册信息
            icon:'none'
          })
          wx.redirectTo({
            url: '../inThis/inThis',
          })
        },
        fail(res){
          console.log(res.data);
          wx.showToast({
            title: res.data,
          })
        }
      })
  },
  formSubmit: function (e) {
    this.setData({
      form: e.detail.value
    })
    var name = this.data.form.name;
    var idcard = this.data.form.idCard;
    var phone=this.data.form.phone;
    var that = this;
    var judge=wx.getStorageSync("code")
    console.log(this.data.form.verifyNumber == judge)
    var hi=this.data.all;
    if (name.length != 0 && idcard.length == 18 &&this.data.form.verifyNumber==judge&&hi) {
     this.register();
    } else {
      wx.showToast({
        title: '请输入正确的信息',
        icon: 'none',
        duration: 2000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})