// pages/xianyu/details/leave/leave.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    leave:{},
    list:[],
    content:"",
    idCard:"",
    pNickname:"",
    personID:"",
    nickname:"",
    isUser:false,
    value:""
  },
  goodLeave:function(e){
    console.log(e)
    return new Promise(function(resolve,reject){
      wx.request({
        url: 'http://47.104.191.228:8088/get/leave?publishIdCard='+e.publishIdCard+'&pDate='+e.pDate,
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log(res)
          resolve(res.data.msg)
        },
        fail: function (res) {
          console.log("留言失败")
        }
      })
    })
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    var hour = time.getHours()
    var minute = time.getMinutes()
    var second = time.getSeconds()
    const formatNumber1 = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber1).join('-') + " " + [hour, minute, second].map(formatNumber1).join(':')
  },
  getContent: function (e) {
    var content = e.detail.value
    this.setData({
      content: content
    })
  },
  myLeave: function () {
    var _this = this
    var content = this.data.content
    if (content == "") {
      wx.showToast({
        title: '留言内容不能为空!',
        icon: 'none',
        duration: 2000
      })
    } else {
      var msg = JSON.stringify({
        idCard: _this.data.leave.idCard,
        publishIdCard: _this.data.leave.publishIdCard,
        pDate: _this.data.leave.pDate,
        date: _this.myTime(),
        content: _this.data.content,
        personID:_this.data.personID,
        pNickname:_this.data.pNickname,
        status:"false",
        nickname:_this.data.nickname
      })
      console.log(msg)
      wx.request({
        url: 'http://47.104.191.228:8088/leave',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          wx.showToast({
            title: '留言成功',
            icon:'none',
            duration:2000
          })
          var leave = _this.data.leave
          console.log(leave)
          _this.goodLeave(leave).then((res) => {
            _this.setData({
              content: "",
              list: res,
              value:""
            })
          })
        },
        fail: function (res) {
          console.log("取消举报失败")
        }
      })
    }
  },
  delLeave:function(e){
    var _this=this
    var msg=JSON.stringify(e.currentTarget.dataset.leave)
    wx.request({
      url: 'http://47.104.191.228:8088/delete/my/leave',
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      data: {
        msg: msg
      },
      dataType: "JSON",
      success: function (res) {
        console.log(res)
        var leave = _this.data.leave
        console.log(leave)
        _this.goodLeave(leave).then((res) => {
          _this.setData({
            content: "",
            list: res
          })
        })
      },
      fail: function (res) {
        console.log("取消举报失败")
      }
    })
  },
  reply: function (e) {
    var reply = e.currentTarget.dataset.item
    console.log(reply)
    var value = "@" + reply.nickname+" "+reply.content
    this.setData({
      personID:reply.idCard,
      pNickname:reply.nickname,
      value:value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this
    console.log(options)
    var leave = JSON.parse(options.leave)
    var app=getApp()
    this.goodLeave(leave).then((res)=>{
      var isUser = (leave.publishIdCard == app.globalData.realInfo.idCard)
      _this.setData({
        leave: leave,
        list:res,
        idCard:app.globalData.realInfo.idCard,
        personID:leave.publishIdCard,
        pNickname:leave.pNickname,
        nickname:app.globalData.userInfo.nickName,
        isUser:isUser
      })
      console.log(_this.data.isUser)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})