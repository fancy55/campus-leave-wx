// pages/Set/Set.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: {
      listArr: [],
      publish:true
    },
  },
  //删除已发布的商品
  removeThis:function(e){
    var index = e.currentTarget.dataset.index;
    console.log("选择第几个",index)
    var msg=JSON.stringify({
      "publishIdCard": app.globalData.userInfo.idCard,
      "pdate":this.data.listArr[index].pdate
    })
    //删除已发布的闲置
    wx.request({
      url: 'http://47.104.191.228:8088/delete/goods',
      method: "post",
      data: {
        msg: msg
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res)
          wx.showToast({
            title: res.data,
            icon: 'none'
          })
        this.onLoad();
      }
    })
  },
  //进入详情页
  inDetails: function (e) {
    var index = e.currentTarget.dataset.index;
    console.log("进入第几个", index);
    var msg = JSON.stringify(this.data.listArr[index]);
    app.globalData.mySet=false;//在此界面为false，其他都为true
    console.log(msg)
    app.globalData.isBuy = true;
    wx.navigateTo({
      url: '../details/details?msg=' + msg,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: 'http://47.104.191.228:8088/get/my/publish',
      method: "get",
      data: {
        msg: {
          "publishIdCard": app.globalData.userInfo.idCard,
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: (res) => {
        this.setData({
          listArr: res.data.msg
        })
        if (this.data.listArr.length == 0) {
          wx.showToast({
            title: '还没有闲置的哦，去添加吧！',
            icon: 'none'
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.onLoad();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})