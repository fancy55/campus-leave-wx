// pages/otherPage/otherPage.js
const app=getApp();
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:false,   //信息页面是否开启
    goods: true,   //商品页面是否开启
    photo:null,
    goodsArr: [],  //商品详情
    infoArr:{},    //这个人的信息
    allInfo:{},   //我的信息
    right:true  //是否被关注

  },
  inDetails: function (e) {
    var index = e.currentTarget.dataset.index;
    console.log("进入第几个", index);
    var msg = JSON.stringify(this.data.listArr[index]);
    console.log(msg)
    if(this.data.status===("yes")){
    app.globalData.isBuy = true;
    }
    wx.navigateTo({
      url: '../details/details?msg=' + msg,
    })
  },
  //点击信息，转变样式
  tickInfo:function(){
    var info=this.data.info;
    this.setData({
      info:!info,

    })
  },
  //点击收起商品样式
  tickGoods: function () {
    var goods = this.data.goods;
    this.setData({
      goods: !goods,
    })
  },
  focus:function(){
    // "publishIdCard": this.data.infoArr.idCard,
    var msg = JSON.stringify({
      "idCard": this.data.allInfo.idCard,
      "publishIdCard": this.data.infoArr.idCard,
      "Date": util.formatTime(new Date())
    })
    console.log(msg);
      wx.request({                                   //请求关注
        url: 'http://47.104.191.228:8088/focus',
        method: "post",
        data: {
          "msg": msg
        },
        dataType: "json",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: (res) => {
          console.log(res)
          if(res.data==("关注成功")){
          wx.showToast({
            title: '关注成功',
            icon: 'success',
            duration: 2000
          })
          this.setData({
            right:false
          })
          }else{
            wx.showToast({
              title: '您已关注',
              icon: 'success',
              duration: 2000
            })
            this.setData({
              right: false
            })
          }
        },
        fail(res){
          console.log(res)
        }
      })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log("看信息有无传进来", app.globalData.indexId)
    var that=this;
    var msg=JSON.stringify({
      "publishIdCard": app.globalData.indexId.idCard
    })
    wx.request({                       //得到商品详情
      url: 'http://47.104.191.228:8088/get/my/publish',
      method: "get",
      data: {
        msg: msg
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: (res) => {
        this.setData({
          goodsArr: res.data.msg
        })
      }
    }),
    //设置需要的信息
      this.setData({
        infoArr:app.globalData.indexId
      }),
      this.setData({
      allInfo:app.globalData.userInfo
      }),
      console.log(app.globalData.indexId.photo)
      this.setData({
        photo: app.globalData.indexId.photo
      })
      //查看是否已经关注
    var _msg = JSON.stringify({
      "idCard":  this.data.allInfo.idCard,
        "publishIdCard": app.globalData.indexId.idCard
    })

      wx.request({                       
        url: 'http://47.104.191.228:8088/isfocus',
      method: "get",
      data: {
        msg: _msg
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: (res) => {
         console.log(res)
         if(res.data===("已关注")){
         this.setData({
           right:false
         })
         }
      }
    })
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.onLoad();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})