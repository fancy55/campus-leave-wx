// pages/xianyu/xianyu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    follow_btn:"btn",
    index_btn:"btn_tap",
    index_list:[],
    follow_list:[],
    isIphoneX:"" ,
    loading:true
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    const formatNumber = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber).join('-')
  },
  follow: function () {
    var _this = this
    this.getFollow().then((res) => {
      console.log(res)
      _this.setData({
        follow_btn: "btn_tap",
        index_btn: "btn",
        follow_list: res
      })
    })
  },
  index: function () {
    var _this = this
    this.getIndex().then((res) => {
      console.log(res)
      _this.setData({
        index_btn: "btn_tap",
        follow_btn: "btn",
        index_list: res
      })
    })
  },
  getIndex: function () {
    var _this = this
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/find/all/free',
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log(res)
          _this.getList(res.data).then((result) => {
            resolve(result)
          })
        }, 
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  getList: function (e) {
    return new Promise(function (resolve, reject) {
      var reg = new RegExp('PublishGoods', "g")
      var data = e.replace(reg, "")
      data = data.split(")")
      var list = []
      for (var i = 0; i < data.length - 1; i++) {
        if (i == 0) {
          data[i] = data[i].slice(2)
        } else {
          data[i] = data[i].slice(3)
        }
        var l1 = data[i].split(",")
        for (var j = 0; j < l1.length; j++) {
          var index = l1[j].indexOf("=")
          l1[j] = l1[j].slice(index + 1)
        }
        list[i] = {
          name: l1[0],
          price: l1[1],
          description: l1[2],
          status: l1[3],
          category: l1[4],
          nickName: l1[5],
          publishIdCard: l1[6],
          pDate: l1[7],
          buyerIdCard: l1[8],
          address: l1[9],
          date: l1[10],
          photo1: l1[11],
          photo2: l1[12],
          photo3: l1[13],
          photo4: l1[14],
          photo5: l1[15],
          photo6: l1[16],
          photo:l1[17]
        }
      }
      console.log(list)
      resolve(list)
    })
  },
  getFollow:function(){
    var _this = this
    var app=getApp()
    var e = JSON.stringify({
      idCard: app.globalData.realInfo.idCard
    })
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/get/focus',
        method: "GET",
        data:{
          msg: e
        },
        dataType:"JSON",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log(res.data)
          var result = JSON.parse(res.data).msg
          resolve(result)
       },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  checkDetails:function(e){
    console.log(e.detail)
    var good = JSON.stringify(e.detail)
    wx.navigateTo({
      url: './details/details?good='+good,
    })
  },
  cancel: function (e) {
    var idCard = e.detail;
    var _this=this
    var app=getApp()
    console.log(idCard)
    var msg = JSON.stringify({
      "idCard": app.globalData.realInfo.idCard,
      "publishIdCard": idCard
    })
    wx.request({
      url: 'http://47.104.191.228:8088/cancel/focus',
      method: "post",
      data: {
        "type": "cancel",
        "msg": msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res.data)
        this.getFollow().then((res) => {
          console.log(res)
          _this.setData({
            follow_list: res
          })
        })
      },
    })
  },
  toFocus: function(e) {
    var user = e.detail
    console.log(user)
    var app=getApp()
    app.globalData.indexId=user
    wx.navigateTo({
      url: '../otherPage/otherPage'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this
    var app = getApp()
    this.getIndex().then((res) => {
      console.log(res)
      _this.setData({
        index_list: res,
        isIphoneX:app.globalData.isIphoneX,
        loading:false
      })
    })
    
    //得到信息
    var that = this;
    wx.request({
      url: "http://47.104.191.228:8088/user/get/info",
      method: "get",
      data: {
        "msg": {
          "idCard": app.globalData.realInfo.idCard,
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        // console.log("加载");
        app.globalData.userInfo = res.data.msg

      },
    })
    console.log(app.globalData.userInfo.nickName === ('昵称'))
    if(app.globalData.userInfo.nickName===('昵称')){
      wx.showToast({
        title: '您还未修改资料，赶快去完善吧！',
        icon:'none'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})