// pages/xianyu/result/result.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    result:"书籍",
    list:[]
  },
  getResult:function(e){
    var _this=this
    console.log(e)
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/find/'+e,
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          if(res.data==""){
            resolve("")
          }else{
            _this.getList(res.data).then((result) => {
              resolve(result)
            })
          }  
        },
        fail: function (res) {
          console.log("更新" + res.data.msg)
        }
      })
    })
  },
  getList:function(e){
    return new Promise(function (resolve, reject) {
      var reg = new RegExp('PublishGoods', "g")
      var data = e.replace(reg, "")
      data = data.split(")")
      var list = []
      for (var i = 0; i < data.length - 1; i++) {
        if (i == 0) {
          data[i] = data[i].slice(2)
        } else {
          data[i] = data[i].slice(3)
        }
        var l1 = data[i].split(",")
        for (var j = 0; j < l1.length; j++) {
          var index = l1[j].indexOf("=")
          l1[j] = l1[j].slice(index + 1)
        }
        list[i] = {
          name: l1[0],
          price: l1[1],
          description: l1[2],
          status: l1[3],
          category: l1[4],
          nickName: l1[5],
          publishIdCard: l1[6],
          pDate: l1[7],
          buyerIdCard: l1[8],
          address: l1[9],
          date: l1[10],
          photo1: l1[11],
          photo2: l1[12],
          photo3: l1[13],
          photo4: l1[14],
          photo5: l1[15],
          photo6: l1[16],
          photo:  l1[17]
        }
      }
      console.log(list)
      resolve(list)
    })
  },
  getTitle:function(e){
    console.log(e)
    if(e=="book")return "书籍";
    else if(e=="clothing")return "衣服";
    else if (e == "cosmetics") return "化妆品";
    else if (e == "sporting") return "运动";
    else if (e == "planting") return "园艺";
    else if (e == "games") return "游戏";
    else if (e == "instrument") return "乐器";
    else if (e == "ticket") return "卡券（电影票或其他)";
    else if (e == "household") return "家具百货";
    else if (e == "digital") return "数码产品";
    else return "其他"
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this=this
    if (options.result){
      var result = options.result
      var title = this.getTitle(result)
      console.log(title + result)
      this.getResult(result).then((res) => {
        console.log(res)
        if(res==""){
          wx.showToast({
            title: '此页面没有相关商品',
            icon:'none',
            duration:2000
          })
        }else{
          _this.setData({
            list: res,
            result: result
          })
        }
      })
      wx.setNavigationBarTitle({
        title: title
      })
    }else{
      var list=JSON.parse(options.list)
      wx.setNavigationBarTitle({
        title: "搜索结果"
      })
      if(list.length==0){
        wx.showToast({
          title: '搜索结果为空',
          icon: 'none',
          duration: 2000
        })
      }else{
        _this.setData({
          list: list
        })
      }
    }  
  },
  checkDetails: function (e) {
    console.log(e.currentTarget.dataset.good)
    var good = JSON.stringify(e.currentTarget.dataset.good)
    wx.navigateTo({
      url: '../details/details?good=' + good,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.navigateBack({delta:2})
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})