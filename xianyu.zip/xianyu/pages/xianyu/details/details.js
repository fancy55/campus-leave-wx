// pages/xianyu/details/details.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    good:{},
    bnrUrl:[],
    msg:{},
    report:false,
    like:false,
    favor:false
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    var hour = time.getHours()
    var minute = time.getMinutes()
    var second = time.getSeconds()
    const formatNumber1 = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber1).join('-') + " " + [hour, minute, second].map(formatNumber1).join(':')
  },
  getLike:function(){
    var _this=this
    var app=getApp()
    var like = _this.data.like
    if(!like){
      var msg = JSON.stringify({
        idCard: app.globalData.realInfo.idCard,
        date: _this.myTime(),
        publishIdCard: _this.data.good.publishIdCard,
        pDate: _this.data.good.pDate
      })
      wx.request({
        url: 'http://47.104.191.228:8088/like',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          _this.setData({
            like: !like
          })
        },
        fail: function (res) {
          console.log("点赞失败")
        }
      })
    }else{
      var msg = _this.data.msg
      wx.request({
        url: 'http://47.104.191.228:8088/cancel/like',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          _this.setData({
            like: !like
          })
        },
        fail: function (res) {
          console.log("取消点赞失败")
        }
      })
    }  
  },
  getFavor: function () {
    var _this = this
    var app = getApp()
    var favor = _this.data.favor
    if (!favor) {
      var msg = JSON.stringify({
        idCard: app.globalData.realInfo.idCard,
        date: _this.myTime(),
        publishIdCard: _this.data.good.publishIdCard,
        pDate: _this.data.good.pDate
      })
      wx.request({
        url: 'http://47.104.191.228:8088/favor',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg:msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          _this.setData({
            favor: !favor
          })
        },
        fail: function (res) {
          console.log("收藏失败")
        }
      })
    } else {
      var msg = _this.data.msg
      wx.request({
        url: 'http://47.104.191.228:8088/delete/favor',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          _this.setData({
            favor: !favor
          })
        },
        fail: function (res) {
          console.log("取消收藏失败")
        }
      })
    }
  },
  getLeave:function(){
    var msg = this.data.msg
    wx.navigateTo({
      url: './leave/leave?leave=' + msg,
    })
  },
  getReport: function () {
    var _this = this
    var app = getApp()
    var report = _this.data.report
    if (!report) {
      var msg = _this.data.msg
      wx.navigateTo({
        url: './report/report?report='+msg,
      })
    } else {
      var e = JSON.parse(_this.data.msg)
      var msg = JSON.stringify({
        reportIdCard:e.idCard,
        publishIdCard:e.publishIdCard,
        pDate:e.pDate
      })
      wx.request({
        url: 'http://47.104.191.228:8088/cancel/report',
        method: "POST",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: msg
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          _this.setData({
            report: !report
          })
        },
        fail: function (res) {
          console.log("取消举报失败")
        }
      })
    }
  },
  getBuy:function(){
    var _this=this
    var e = JSON.parse(_this.data.msg)
    var msg = JSON.stringify({
      buyeridCard: e.idCard,
      publishIdCard: e.publishIdCard,
      pDate: e.pDate,
      date:_this.myTime()
    })
    wx.request({
      url: 'http://47.104.191.228:8088/buy',
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      data: {
        msg: msg
      },
      dataType: "JSON",
      success: function (res) {
        console.log(res)
        if (res.data =="无法自己购买"){
          wx.showToast({
            title: "无法购买自己发布的商品",
            icon: 'none',
            duration: 2000
          })
        } else if (res.data == "购买成功"){
          wx.showToast({
            title: '购买成功,请去个人中心查看',
            icon: 'none',
            duration: 2000
          })
        }  
      },
      fail: function (res) {
        console.log("购买失败")
      }
    })
  },
  myReport:function(e){
    console.log(e)
    var msg = JSON.parse(e)
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/get/goods/report',
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          reportIdCard: msg.idCard,
          publishIdCard: msg.publishIdCard,
          pDate: msg.pDate
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res.data)
          var data = JSON.parse(res.data)
          resolve(data.msg)
        },
        fail: function (res) {
          console.log("获取举报失败")
        }
      })
    })
  },
  mylike: function (e) {
    console.log(e)
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/get/status/like',
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: e
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          resolve(res.data)
        },
        fail: function (res) {
          console.log("获取举报失败")
        }
      })
    })
  },
  myfavor: function (e) {
    console.log(e)
    return new Promise(function (resolve, reject) {
      wx.request({
        url: 'http://47.104.191.228:8088/get/status/favor',
        method: "GET",
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        data: {
          msg: JSON.parse(e)
        },
        dataType: "JSON",
        success: function (res) {
          console.log(res)
          resolve(res.data)
        },
        fail: function (res) {
          console.log("获取举报失败")
        }
      })
    })
  },
  toFocus: function (e) {
    var msg =JSON.stringify({
      idCard: e.currentTarget.dataset.user
    }) 
    console.log(msg)
    wx.request({
      url: 'http://47.104.191.228:8088/user/get/info',
      method: "GET",
      data: {
        msg:msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        var user = res.data.msg
        console.log(user)
        var app = getApp()
        app.globalData.indexId = user
        wx.navigateTo({
          url: '../../otherPage/otherPage'
        })
      },
    })
   
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var good=JSON.parse(options.good)
    var _this=this
    var app = getApp()
    var idCard = app.globalData.realInfo.idCard
    var msg = JSON.stringify({
      idCard: app.globalData.realInfo.idCard,
      publishIdCard: good.publishIdCard,
      pDate: good.pDate
    })
    var photo = [
      { url: good.photo1 },
      { url: good.photo2 },
      { url: good.photo3 },
      { url: good.photo4 },
      { url: good.photo5 },
      { url: good.photo6 }
    ]
    this.setData({
      good: good,
      bnrUrl: photo,
      msg: msg
    })
    this.setData({
      msg: msg
    })
    this.mylike(msg).then((res)=>{
      if(res=="已点赞"){
        _this.setData({
          like:true
        })
      }else{
        _this.setData({
          like: false
        })
      }
    })
    this.myfavor(msg).then((res)=>{
      if (res == "已收藏") {
        _this.setData({
          favor: true
        })
      } else {
        _this.setData({
          favor: false
        })
      }
    })
    this.myReport(msg).then((res) => {
      if(res==null){
        _this.setData({
          report: false
        })
      }else{
        _this.setData({
          report: true
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this
    var app = getApp()
    var idCard = app.globalData.realInfo.idCard
    var msg = this.data.msg
    this.myReport(msg).then((res) => {
      if (res == null) {
        _this.setData({
          report: false
        })
      } else {
        _this.setData({
          report: true
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})