// pages/feedback/feedback.js
var util=require('../../utils/util.js');
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text:"",
    time:""
  },
  bindTextAreaBlur: function (e) {
    this.setData({
     text:e.detail.value
      })
  },

  formSubmit: function (e) {
    this.setData({
      time: util.formatTime(new Date())
    })
    var thisText = this.data.text;
    var thisTime = this.data.time;
    var msg = JSON.stringify({
      "phone": app.globalData.userInfo.phone,
      "content": thisText,
      "date": thisTime
    })
    if (thisText!==""){
    wx.request({
      url: 'http://47.104.191.228:8088/feedback/insert',
      method: "post",
      data: {
        msg:msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log(res.data)
        wx.showToast({
          title: '反馈成功',
          icon: 'success',
          duration: 2000
        })
        wx.navigateBack({
          url:"../My/My"
        })
      },
    })
    }else {
      wx.showToast({
        title: '请输入内容',
        icon: 'loading',
        duration: 1000
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})