// pages/sell/sell.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    img:[],
    value:"",
    category:"book",
    multiArray: [['行健轩', '至诚轩', '弘毅轩','敏行轩', '留学生公寓'], ['1', '2', '3', '4'], ['A', 'B']],
    multiIndex: [0, 0, 0],
    accounts: ["书籍", "衣服", "化妆品", "运动", "园艺", "游戏", "乐器", "卡券（电影票或其他", "家具百货", "数码产品", "其他"],
    accountIndex: 0
  },
  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },
  bindMultiPickerColumnChange: function (e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (e.detail.column) {
      case 0:
        switch (data.multiIndex[0]) {
          case 0:
            data.multiArray[1] = ['1', '2', '3', '4'];
            data.multiArray[2] = ['A', 'B'];
            break;
          case 1:
            data.multiArray[1] = ['1', '2', '3', '4'];
            data.multiArray[2] = ['A', 'B'];
            break;
          case 2:
            data.multiArray[1] = ['1', '2', '3', '4'];
            data.multiArray[2] = ['A', 'B'];
            break;
          case 3:
            data.multiArray[1] = [''];
            data.multiArray[2] = [''];
            break;
          case 4:
            data.multiArray[1] = [''];
            data.multiArray[2] = [''];
            break;
        }
        data.multiIndex[1] = 0;
        data.multiIndex[2] = 0;
        break;
    }
    console.log(data.multiIndex);
    this.setData(data);
  },
  getCategory: function (e) {
    var accounts = this.data.accounts
    var category = this.getResult(accounts[e.detail.value])
    this.setData({
      accountIndex: e.detail.value,
      category:category 
    })
    console.log(this.data.category);
  },
  getResult: function (e) {
    console.log(e)
    if (e == "书籍") return "book";
    else if (e == "衣服") return "clothing";
    else if (e == "化妆品") return "cosmetics";
    else if (e == "运动") return "sporting";
    else if (e == "园艺") return "planting";
    else if (e == "游戏") return "games";
    else if (e == "乐器") return "instrument";
    else if (e == "卡券（电影票或其他") return "ticket";
    else if (e == "家具百货") return "household";
    else if (e == "数码产品") return "digital";
    else return "others"
  },
  getPhoto: function () {
    var _this=this
    wx.chooseImage({
      count:6,
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        console.log(tempFilePaths)
        _this.setData({
          img: tempFilePaths
        })
        console.log(_this.data.img)
      }
    })
  },
  myTime: function () {
    var time = new Date()
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var day = time.getDate()
    var hour=time.getHours()
    var minute=time.getMinutes()
    var second=time.getSeconds()
    const formatNumber1 = n => {
      n = n.toString()
      return n[1] ? n : '0' + n
    }
    return [year, month, day].map(formatNumber1).join('-') + " "+[hour, minute, second].map(formatNumber1).join(':')
  },
  update:function(e){
    var _this = this
    var img = this.data.img
    var msg = JSON.stringify(e)
    return new Promise(function(resolve,reject){
      for (var i = 0; i < img.length; i++) {
        wx.uploadFile({
          url: 'https://www.qlybit.xyz:8087/publish', //仅为示例，非真实的接口地址
          filePath: img[i],
          name: "file",
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            "size": i + 1,
            "msg": msg
          },
          success: function (res) {
            resolve(img)
            //do something
          }
        })
      }
    })
  },
  formSubmit:function(e){
    console.log(e.detail.value)
    var result=e.detail.value
    var _this=this
    var multiArray=this.data.multiArray
    var multiIndex=this.data.multiIndex
    var address = multiArray[0][multiIndex[0]]+multiArray[1][multiIndex[1]] +multiArray[2][multiIndex[2]]
    console.log(address)
    var app=getApp()
    var publishGood={
      name:result.name,
      description:result.description,
      price:result.price,
      address:address,
      category:_this.data.category,
      status:"no",
      nickName: app.globalData.userInfo.nickName,
      publishIdCard:app.globalData.userInfo.idCard,
      pDate: _this.myTime(),
      buyerIdCard:"",
      date:"",
      photo:app.globalData.userInfo.photo
    }
    if (result.name == ""){
      wx.showToast({
        title: '商品名称不能为空！',
        icon:"none",
        duration:2000
      })
    }else if (result.description == ""){
      wx.showToast({
        title: '商品描述不能为空！',
        icon: "none",
        duration: 2000
      })
    } else if (result.price == ""){
      wx.showToast({
        title: '商品价格不能为空！',
        icon: "none",
        duration: 2000
      })
    }else{
      _this.update(publishGood).then((res) => {
        wx.uploadFile({
          url: 'https://www.qlybit.xyz:8087/publish', //仅为示例，非真实的接口地址
          filePath: res[0],
          name: "file",
          header: {
            "Content-Type": "multipart/form-data"
          },
          formData: {
            "size": -1,
            "msg": JSON.stringify(publishGood)
          },
          success: function (res) {
            console.log(res)
            if (res.data == "缓存成功") {
              _this.toXianyu()
            }
          }
        })
      })
    }
  },
  toXianyu:function(){
    wx.switchTab({
      url: '../xianyu/xianyu'
    })
    wx.showTabBar({
    })
    this.setData({
      value: "",
      img: []
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.hideTabBar()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})