// pages/Login2/forget/forget.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   phone:null,
    newpassword:null,
    coderight:null,
    form:null
  },
  //得到手机号
  getnumber: function (e) {
    console.log(e.detail.value);
    var number = e.detail.value;
    if (number.length != 11) {
      wx.showToast({
        title: '请输入正确手机号',
        icon: "none"
      })
    } else {
      this.setData({
        phone: e.detail.value
      })
    }
  },
  getCode: function () {
    console.log("获取验证码", this.data.phone);
    var phone = this.data.phone
    var that = this
    // console.log(phone)
    if (phone.length == 11) {
      wx.request({
        url: 'http://47.104.191.228:8088/send/' + phone,
        method: "get",
        dataType: "json",
        header: {
          "Content-Type": "application/json;charset=UTF-8"
        },
        success: (res) => {
          console.log(res)
          var list = res.data.data.split(',')
          var code = list[0].slice(5)
          console.log(code)
          wx.setStorageSync("code", code)
        }
      })
      wx.showToast({
        title: '请稍候',
        icon: 'loading',
        duration: 1000
      })
    } else {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none',
        duration: 1000
      })
    }
  },
  getnew: function (e) {
      var newN = e.detail.value;
      if (newN.length >= 6 && newN.length <= 10) {
        this.setData({
          newpassword: newN
        })
        console.log(this.data.newpassword);
      } else {
        wx.showToast({
          title: '请输入正确格式的密码',
          icon: 'none'
        })
      }
  },
  getre: function (e) {
    if (this.data.newpassword != null && e.detail.value == this.data.newpassword) {
      this.setData({
        all: true
      })
      console.log(this.data.all)
    } else {
      wx.showToast({
        title: '前后输入不一致',
        icon: 'none'
      })
    }
  },
  recode:function(e){
    console.log(e.detail.value);
    var judge = wx.getStorageSync("code")
    if (e.detail.value == judge){
     this.setData({
       coderight:true
     })
    }else{
      wx.showToast({
        title: '输入的验证码错误',
        icon:'none'
      })
    }
    console.log(e.detail.value== judge)
  },
  formSubmit:function(e){
    if(this.data.coderight&&this.data.newpassword!=null){
    var msg=JSON.stringify({
      "phone":this.data.phone,
      "password":this.data.newpassword
    })
    console.log("msg",msg)
      wx.request({
        url: "http://47.104.191.228:8088/user/forget/pass",
        method: "post",
        data: {
          msg:msg
        },
        header: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
        },
        success: function (res) {
          console.log("是否修改成功",res.data);
          wx.navigateTo({
            url: '../inThis',
          })
          wx.showToast({
            title: res.data,
            icon:'none'
          })
        },
      })
    }else{
      wx.showToast({
        title: '您输入的信息有误',
        icon:'none'
      })
    }
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})