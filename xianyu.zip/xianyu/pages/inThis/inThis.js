// pages/inThis/inThis.js
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    form: [],
    name: null,
    phone: null,
    password:null,
    currentText: '',
  },
  //前往注册
  toRegister: function () {
    wx.navigateTo({
      url: '../Login2/Login2',
    })
  },
  //提交登陆表格
  formSubmit: function (e) {
    var that=this
    // console.log(e.detail.value)
    this.setData({
      form: e.detail.value
    })
    var msg = JSON.stringify({
      phone: this.data.form.phone,
      password: this.data.form.password
    }
    );
    // console.log(msg);
    wx.request({
      url: 'http://47.104.191.228:8088/user/login',
      method: "post",
      data: {
        msg: msg
      },
      dataType: "json",
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
      },
      success: (res) => {
        console.log("返回信息",res.data.msg)
        if (res.data.msg!=('查无此用户')) {
          wx.switchTab({
            url: '../xianyu/xianyu',
          })
          that.getInfo(res.data.msg.idCard)
          app.globalData.realInfo = res.data.msg;
            // 基本信息保存本地，以便下一次登陆
          wx.setStorageSync('phone', this.data.form.phone);
          wx.setStorageSync('password', this.data.form.password);

        } else {
          wx.showToast({
            title: '请输入正确信息',
            icon: 'loading'
          })

        }
      },
      fail(res) {
        console.log(res)
      }

    })
  },
  getInfo:function(e){
    var that = this;
    wx.request({
      url: "http://47.104.191.228:8088/user/get/info",
      method: "get",
      data: {
        "msg": {
          "idCard": e,
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        // console.log("加载");
        app.globalData.userInfo = res.data.msg
      },
    })
  },
  //去找回密码
  forget:function(){
    wx.navigateTo({
      url: 'forget/forget',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var data = this.data
    this.setData({
      phone: wx.getStorageSync('phone'),
      password: wx.getStorageSync('password'),
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  })