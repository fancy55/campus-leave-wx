// pages/My/My.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    classmiddle:"box_icon",
    classFoot:"down",
    idCard:null,
    nickName: null,
    photo:null,
    scNumber:"★",
    fansNumber:"☆",
    focusNumber:"★",
    withMe:false,

  },
  moveToAll:function(){
    wx.navigateTo({
      url: '../Sold/sellAndBuy/sellAndBuy',
    })
  },
  movePagewithMe: function () {
    wx.navigateTo({
      url: '../My/withMe/withMe',
    })
  },
  movePageSold:function(){
    wx.navigateTo({
      url: '../Sold/Sold',
    })
  },
  movePageBuy: function() {
    app.globalData.whichBuy = false;
    wx.navigateTo({
      url: '../Buy/Buy',
    })

  },
  movePageSet: function () {
    wx.navigateTo({
      url: '../Set/Set',
    })
  },
  movePageFeedback:function() {
    wx.navigateTo({
      url: '../feedback/feedback',
    })
  },
  changePageFavor:function(){
    wx.navigateTo({
      url:"../favor/favor"
    })
  },
  movePageLike:function(){
    wx.navigateTo({
      url: "../likeGoods/likeGoods"
    })
  },
  movePageResetInfo: function () {
    wx.navigateTo({
      url: '../resetInfo/resetInfo',
    })
  },
  movefocus: function () {
    app.globalData.focus="focus";
    app.globalData.fans = "fansdis";
    app.globalData.page = true;
    wx.navigateTo({
      url: '../focus-fans/focus-fans',
    })
  },
  movefans: function () {
    app.globalData.focus = "focusdis";
    app.globalData.fans = "fans";
    app.globalData.page=false;
    // console.log("点击粉丝")
    wx.navigateTo({
      url: '../focus-fans/focus-fans',
    })
  },
  //替代指定位置字符串；
  replaceIt: function (text, start, stop, replacetext) {
    var mystr = text.substring(0, start) + replacetext + text.substring(stop);
    return mystr;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  //  console.log(app.globalData.realInfo)
  app.globalData.isBuy=false;
   var that=this;
   //得到用户基本信息
    wx.request({
      url: "http://47.104.191.228:8088/user/get/info",
      method: "get",
      data: {
        "msg": {
          "idCard": app.globalData.realInfo.idCard,
        }
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        // console.log("加载");
        app.globalData.userInfo=res.data.msg
        that.setData({
          idCard: that.replaceIt(app.globalData.userInfo.idCard, 3, 14, "*******"),
        nickName: app.globalData.userInfo.nickName,
        photo: app.globalData.userInfo.photo,
        })
        
      },
    }),
    //得到与我相关数目
    wx.request({
      url: "http://47.104.191.228:8088/get/my/cnt",
      method: "get",
      data: {
        "idCard": app.globalData.userInfo.idCard

      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        console.log("cnt", res.data);
        if(res.data.msg){
          that.setData({
            withMe: res.data.msg
          })
        }
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})