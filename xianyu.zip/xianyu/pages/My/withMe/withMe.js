// pages/My/withMe/withMe.js
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    focus:"focus",
    fans:"fansdis",
    page: true,
    arrLeave: [],
    hisLeave: [],
  },
  // 未看留言
  tickFocus: function () {
    this.setData({
      focus: "focus",
      fans: "fansdis",
      page: true
    })

  },
  // 已看留言
  tickFans: function () {
    this.setData({
      focus: "focusdis",
      fans: "fans",
      page: false
    })
    this.read();
    this.getLeave();
  },
  read:function(){
    wx.request({
      url: "http://47.104.191.228:8088/update/my/leave",
      method: "get",
      data: {
        "idCard": app.globalData.userInfo.idCard
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        console.log(res.data);
      },
    })
  },
  getLeaveDetail:function(e){
    var index = e.currentTarget.dataset.index;
    console.log("得到index", index)
    if(this.data.focus===("focus")){
    var leave=this.data.arrLeave[index];
    } else{
      var leave = this.data.hisLeave[index];
    }
    console.log("设置的leave",leave)
    wx.request({
      url: 'http://47.104.191.228:8088/get/detail',
        method: "get",
        data: {
            "publishIdCard": leave.publishIdCard,
            "pDate":leave.pdate
        },
        header: {
          "Content-Type": "application/json;charset=UTF-8"
        },
        success: function (res) {
          console.log("得到商品详情",res);
          var msg = JSON.stringify(res.data);
          console.log(msg)
          wx.navigateTo({
            url: '../../details/details?msg=' + msg,
          })
        },
    })
  },
  getLeave:function(){
    var that=this
    wx.request({
      url: "http://47.104.191.228:8088/get/my/leave",
      method: "get",
      data: {
        "idCard": app.globalData.userInfo.idCard
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      success: function (res) {
        console.log("leave", res.data);
        that.setData({
          arrLeave:res.data.msg[1],
          hisLeave:res.data.msg[3]
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getLeave();
    console.log(app.globalData.userInfo)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log("关闭页面")
    var pages = getCurrentPages(); // 当前页面
    var beforePage = pages[pages.length - 2]; // 前一个页面
    var that = this
    wx.navigateBack({
      success: function () {
        beforePage.onLoad(); // 执行前一个页面的onLoad方法
        that.read();
      }
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
   this.read();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})